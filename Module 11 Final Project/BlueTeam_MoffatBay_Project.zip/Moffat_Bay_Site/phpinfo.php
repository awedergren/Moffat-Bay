<?php
/*
Blue Team: Jonah Aney, Justin Marucci, Nardos Gabremedhin, Amanda Wedergren
Date: February 15, 2026
Project: Moffat Bay Marina Project
File: phpinfo.php
Purpose: Diagnostic phpinfo() page. Header is non-executing.
*/
phpinfo();
