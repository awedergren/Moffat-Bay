<?php
/*
Blue Team: Jonah Aney, Justin Marucci, Nardos Gabremedhin, Amanda Wedergren
Date: February 15, 2026
Project: Moffat Bay Marina Project
File: footer.php
Purpose: Site footer partial included on all pages.
Non-executing header only.
*/
?>
<footer class="site-footer">
  <p>&copy; 2026 Moffat Bay Island Marina</p>
</footer>
