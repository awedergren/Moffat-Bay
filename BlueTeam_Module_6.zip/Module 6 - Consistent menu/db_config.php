<?php
// Project DB configuration for local XAMPP setup
return [
  'host' => 'localhost',
  'port' => 3306,
  'dbname' => 'moffat_bay',
  'user' => 'marina',
  'pass' => 'moffatbaymarina',
  'charset' => 'utf8mb4',
];
